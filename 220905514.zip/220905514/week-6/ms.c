#include<stdio.h>
#include<stdlib.h>

int opcount=0;

void merge(int* B, int p, int* C, int q, int* A){
    int i = 0;
    int j = 0;
    for(int k = 0; k < p + q; k++){
    	opcount++;
        if(i < p && (j >= q || B[i] < C[j])) // Fix: Compare elements only if there are elements left in both B and C
            A[k] = B[i++];
        else
            A[k] = C[j++];
    }
}


void mergesort(int* A, int n){
	if(n==1)
		return;

	int* B = (int*)malloc((n/2)*sizeof(int));
	int* C = (int*)malloc((n-(n/2))*sizeof(int));
	for(int i=0; i<n/2;i++)
		B[i]=A[i];
	for(int i=n/2;i<n;i++)
		C[i-n/2]=A[i];
	mergesort(B, n/2);
	mergesort(C, n-n/2);
	merge(B, n/2,C,n-n/2, A);
}



int main(){
	int A[] = {5,4,8,9,6,3, 10, 2};
	mergesort(A, 8);
	printf("Sorted Array: ");
	for(int i=0;i<8;i++)
		printf("%d ", A[i]);
	printf("\nOpcount: %d\n", opcount);
	return 0;
}
