/*#include<stdio.h>


void genPerm(int mat[][10], int* perm, int ind, int p, int *minCost){
	if (ind == p){
		int currentCost = 0;
        for (int i = 0; i < p; i++) {
            currentCost += mat[i][perm[i]];
        }
        if (currentCost < *minCost) {
            *minCost = currentCost;
        }
		return;
	}

	for(int i=0;i<p;i++){
		perm[ind]=i;
		genPerm(mat, perm, ind+1, p, minCost);
	}
}

int main(){

	int p;
	printf("Enter no of persons/jobs: ");
	scanf("%d", &p);
	int mat[p][p];
	printf("Enter the cost matrix (%dx%d):\n", p, p);
    for (int i = 0; i < p; i++) {
        for (int j = 0; j < p; j++) {
            scanf("%d", &mat[i][j]);
        }
    }
	int perm[p];
	int minCost = 1000;

	genPerm(mat, perm, 0, p, &minCost);

	// Output the result
    printf("Optimal Assignment with Minimum Cost: \n");
    for (int i = 0; i < p; i++) {
        printf("Person %d -> Job %d\n", i + 1, perm[i] + 1);
    }

    printf("Minimum Cost: %d\n", minCost);

    return 0;

}


#include <stdio.h>
#include <stdlib.h>
#include<limits.h>
#define N 4 // Number of tasks or agents

int costMatrix[N][N]; // Cost matrix representing the assignment costs

int minCost = INT_MAX; // Variable to store the minimum cost
int assignment[N]; // Array to store the final assignment

// Function to calculate the total cost of the assignment
int calculateCost(int assignment[]) {
    int totalCost = 0;
    for (int i = 0; i < N; i++) {
        totalCost += costMatrix[i][assignment[i]];
    }
    return totalCost;
}

// Function to generate all possible assignments and find the minimum cost
void generateAssignments(int taskIndex) {
    if (taskIndex == N) {
        int currentCost = calculateCost(assignment);
        if (currentCost < minCost) {
            minCost = currentCost;
        }
        return;
    }

    for (int agentIndex = 0; agentIndex < N; agentIndex++) {
        assignment[taskIndex] = agentIndex;
        generateAssignments(taskIndex + 1);
    }
}

int main() {
    // Input the cost matrix
    printf("Enter the cost matrix (%dx%d):\n", N, N);
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            scanf("%d", &costMatrix[i][j]);
        }
    }

    // Find the optimal assignment using brute force
    generateAssignments(0);

    // Output the result
    printf("Optimal Assignment with Minimum Cost: \n");
    for (int i = 0; i < N; i++) {
        printf("Task %d -> Agent %d\n", i + 1, assignment[i] + 1);
    }

    printf("Minimum Cost: %d\n", minCost);

    return 0;
}
*/

// #include <stdio.h>
// int opcount=0;
// void swap(int* x, int* y) {
//     int temp = *x;
//     *x = *y;
//     *y = temp;
// }

// void copy(int* arr, int* indexArr, int m) {
//     for (int i = 0; i < m; i++) {
//         arr[i] = indexArr[i] + 1;
//     }
// }

// void minCost(int arr[][10], int* indexArr, int start, int end, int m, int* minArr, int* minSal) {
//     if (start == end) {
//         int sum = 0;
//         for (int i = 0; i < m; i++)
//             sum += arr[i][indexArr[i]];
//         opcount+=m;
//         if (*minSal > sum) {
//             *minSal = sum;
//             copy(minArr, indexArr, m);
//         }
//     } else {
//         for (int i = start; i <= end; i++) {
//             swap((indexArr + start), (indexArr + i));
//             minCost(arr, indexArr, start + 1, end, m, minArr, minSal);
//             swap((indexArr + start), (indexArr + i));
//         }
//     }
// }

// int main() {
//     int m;
//     printf("Enter the number of persons/jobs: ");
//     scanf("%d", &m);

//     int arr[m][m];  
//     int indexArr[m];
//     printf("Enter cost matrix: \n");
//     for (int i = 0; i < m; i++) {
//         for (int j = 0; j < m; j++) {
//             scanf("%d", &arr[i][j]);
//         }
// 		indexArr[i] = i;
//     }


//     int minArr[m];
//     int minSal = 1000;



//     minCost(arr, indexArr, 0, m-1, m, minArr, &minSal);

//     printf("Minimum Cost is %d for the array: \n", minSal);
//     for (int i = 0; i < m; i++)
//         printf("%d ", minArr[i]);
//     printf("\nOpcount = %d\n", opcount);
//     return 0;
// }

#include <stdio.h>
#include <limits.h>

int opcount = 0;

void swap(int* x, int* y) {
    int temp = *x;
    *x = *y;
    *y = temp;
}

void copy(int* arr, int* indexArr, int m) {
    for (int i = 0; i < m; i++) {
        arr[i] = indexArr[i] + 1;
    }
}

void minCost(int arr[][10], int* indexArr, int start, int end, int m, int* minArr, int* minSal) {
    if (start == end) {
        int sum = 0;
        for (int i = 0; i < m; i++)
            sum += arr[i][indexArr[i]];
        opcount += m;
        if (*minSal == INT_MAX || *minSal > sum) {
            *minSal = sum;
            copy(minArr, indexArr, m);
        }
    } else {
        for (int i = start; i < end; i++) {
            swap((indexArr + start), (indexArr + i));
            minCost(arr, indexArr, start + 1, end, m, minArr, minSal);
            swap((indexArr + start), (indexArr + i));
        }
    }
}

int main() {
    int m;
    printf("Enter the number of persons/jobs: ");
    scanf("%d", &m);

    int arr[10][10];  // Assuming a fixed maximum size of 10x10
    int indexArr[10];
    printf("Enter cost matrix: \n");
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < m; j++) {
            scanf("%d", &arr[i][j]);
        }
        indexArr[i] = i;
    }

    int minArr[10];  // Assuming a fixed maximum size of 10
    int minSal = INT_MAX;

    minCost(arr, indexArr, 0, m, m, minArr, &minSal);

    printf("Minimum Cost is %d for the array: \n", minSal);
    for (int i = 0; i < m; i++)
        printf("%d ", minArr[i]);
    printf("\nOpcount = %d\n", opcount);

    return 0;
}
