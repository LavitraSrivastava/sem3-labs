#include <stdio.h>
int opcount=0;
void insertion_sort(int* arr, int n){
	int v, j;
	for (int i=1; i<n; i++){
		v=arr[i];
		j=i-1;
		while(++opcount && j>=0 && arr[j]>v){
			arr[j+1]=arr[j];
			j--;
		}
		arr[j+1]=v;
	}
}

int main(){
	int n;
	printf("Enter no of elements: ");
	scanf("%d", &n);
	int arr[n];
	printf("Enter elements: ");
	for(int i=0;i<n;i++)
		scanf("%d", &arr[i]);
	insertion_sort(arr, n);
	printf("Sorted array: ");
	for(int i=0;i<n;i++)
		printf("%d ", arr[i]);
	printf("\nOpcount = %d\n",opcount);
	return 0;
}