#include<stdio.h>
#include<stdlib.h>

void col_sum(int* colsum, int** mat, int vertices){
	for(int i=0;i<vertices;i++)
		for(int j=0;j<vertices;j++)
			colsum[i]+=mat[j][i];
}



int top_seq[20];
int ind=-1;

void topologicalSort(int* colsum, int** mat, int vertices){
	while(1){
		int found = 0;
		for(int i=0;i<vertices;i++){
			if (colsum[i]==0){
				found=1;
				top_seq[++ind]=i+1;
				colsum[i]=-1;
				for(int j=0;j<vertices;j++)
					if(mat[i][j])
						colsum[j]--;
			}	
		}
		if(!found)
			break;
	}
	
}

int main(){
	int vertices;
	printf("Enter no of vertices: ");
	scanf("%d", &vertices);
	int** mat;
	int* colsum;
	mat = (int**)malloc(vertices*sizeof(int*));
	colsum = (int*)malloc(vertices*sizeof(int));
	printf("Enter adjacency matrix: \n");
	for(int i=0;i<vertices;i++){
		colsum[i]=0;
		mat[i]=(int*)malloc(vertices*sizeof(int));
		for(int j=0;j<vertices;j++)
			scanf("%d", &mat[i][j]);
	}

	col_sum(colsum, mat, vertices);
	topologicalSort(colsum, mat, vertices);
	printf("Topological sort sequence: ");
	for(int i=0;i<=ind;i++)
		printf("%d ", top_seq[i]);
	printf("\n");
	return 0;
}