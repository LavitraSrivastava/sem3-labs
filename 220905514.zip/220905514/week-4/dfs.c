#include <stdio.h>

#define MAX_VERTICES 10

int mat[MAX_VERTICES][MAX_VERTICES];
int vertices;
int visited[MAX_VERTICES];
int stack[MAX_VERTICES];
int top = -1;

// Arrays to store push and pop orders
int pushOrder[MAX_VERTICES];
int popOrder[MAX_VERTICES];
int pushIndex = 0;
int popIndex = 0;

void push(int vertex) {
    stack[++top] = vertex;
    pushOrder[pushIndex++] = vertex; // Use zero-based index
}

int pop() {
    popOrder[popIndex++] = stack[top];
    return stack[top--];
}

int isStackEmpty() {
    return top == -1;
}

void dfs_visit(int vertex) {
    visited[vertex] = 1;
    push(vertex); // Push the vertex when visiting

    for (int i = 0; i < vertices; ++i) {
        if (!visited[i] && mat[vertex][i] && i != vertex)
            dfs_visit(i);
    }

    pop(); // Pop the vertex after visiting its neighbors
}

void dfs() {
    for (int i = 0; i < vertices; ++i) {
        if (!visited[i])
            dfs_visit(i);
    }
}

int main() {
    printf("Enter the Number of Vertices: \n");
    scanf("%d", &vertices);
    
    printf("Enter the Adjacency Matrix: \n");
    for (int i = 0; i < vertices; ++i) {
        for (int j = 0; j < vertices; ++j)
            scanf("%d", &mat[i][j]);
    }

    dfs();

    printf("\nPush Order: ");
    for (int i = 0; i < pushIndex; i++) {
        printf("%d ", pushOrder[i] + 1); // Adding 1 to make it 1-based index
    }

    printf("\nPop Order: ");
    for (int i = 0; i < popIndex; i++) {
        printf("%d ", popOrder[i] + 1); // Adding 1 to make it 1-based index
    }

    return 0;
}
