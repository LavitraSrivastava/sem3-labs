#include <stdio.h>
#include <stdlib.h>

int opcount = 0;

void quicksort(int* A, int n){
    if(n <= 1)
        return;
    
    int b = 0;
    int c = 0;
    int* B = (int*)malloc(n * sizeof(int));
    int* C = (int*)malloc(n * sizeof(int));
    int v = A[0]; // Pivot element
    
    // Partitioning step
    for(int i = 1; i < n; i++){
        opcount++; // Increment opcount for each comparison
        if(A[i] < v)
            B[b++] = A[i];
        else
            C[c++] = A[i];
    }
    
    // Recursive calls for subarrays
    quicksort(B, b);
    quicksort(C, c);
    
    // Copy elements back into array A
    for(int i = 0; i < b; i++)
        A[i] = B[i];
    A[b] = v; // Place the pivot element
    for(int i = 0; i < c; i++)
        A[b + 1 + i] = C[i]; // Offset by b+1 for correct position
    
    free(B);
    free(C);
}

int main(){
	int* a;
	int i,n=5;
	for (int j=0; j < 10; j++) // repeat experiment for 4 trials
	{
		a = (int *)malloc(sizeof(int)*n);
		for (int k=0; k< n; k++)
		a[k] = n-k; // descending order list
		printf("Elements are ");
		for(i=0;i<n;i++)
		printf("%d ",a[i]);
		quicksort(a,n);
		printf("\nElements after quick sort ");
		for(i=0;i<n;i++)
			printf("%d ",a[i]);
		printf("\nOpcount: %d\n",opcount);
		free(a);
		opcount=0;
		n = n + 5; // try with a new input size
	}

    return 0;
}
