#include<stdio.h>
#include<stdlib.h>

void col_sum(int* colsum, int** mat, int vertices){
	for(int i=0;i<vertices;i++)
		for(int j=0;j<vertices;j++)
			colsum[i]+=mat[j][i];
}

int top_seq[20];
int ind=-1;

void sourceRemoval(int* colsum, int** mat, int vertices){
	while(1){
		int found = 0;
		for(int i=0;i<vertices;i++){
			if (colsum[i]==0){
				found=1;
				top_seq[++ind]=i+1;
				colsum[i]=-1;
				for(int j=0;j<vertices;j++)
					if(mat[i][j])
						colsum[j]--;
			}	
		}
		if(!found)
			break;
	}
	
}

int stack[20];
int top=-1;
int pop_order[20];
int pop_index=0;

void dfs(int** mat, int vertices, int* visited, int v){
	visited[v]=1; //marked as visited
	stack[++top]=v; // pushed to stack
	for(int i=0;i<vertices;i++)
		if(!visited[i] && mat[v][i] && i!=v)
			dfs(mat, vertices, visited, i);
	int pop=stack[top--]; //popped from stack
	pop_order[pop_index++]=pop+1; // stored in pop_order array
}

int main(){
	int vertices;
	printf("Enter no of vertices: ");
	scanf("%d", &vertices);
	int** mat = (int**)malloc(vertices*sizeof(int*));
	int* visited = (int*)malloc(vertices*sizeof(int));
	int* colsum = (int*)malloc(vertices*sizeof(int));

	printf("Enter adjacency matrix: \n");
	for(int i=0;i<vertices;i++){
		visited[i]=0;
		mat[i]=(int*)malloc(vertices*sizeof(int));
		for(int j=0;j<vertices;j++)
			scanf("%d", &mat[i][j]);
	}

	int choice;
	printf("\n1. DFS Technique \n 2. Source Removal\n 0. Exit");
	printf("Enter choice: ");
	scanf("%d", &choice);
	while(choice!=0){
		switch(choice){
		case 1:
			for(int i=0;i<vertices;i++)
			if(!visited[i])
				dfs(mat, vertices, visited, i);

			printf("Topological sort sequence using DFS	: ");
			for(int i=pop_index-1;i>=0;i--)
				printf("%d ", pop_order[i]);
			printf("\n");
			break;
		case 2:
			col_sum(colsum, mat, vertices);
			sourceRemoval(colsum, mat, vertices);
			printf("Topological sort sequence using Source Removal: ");
			for(int i=0;i<=ind;i++)
				printf("%d ", top_seq[i]);
			printf("\n");
			break;	
		}
		printf("Enter choice: ");
		scanf("%d", &choice);
	}
	return 0;
}