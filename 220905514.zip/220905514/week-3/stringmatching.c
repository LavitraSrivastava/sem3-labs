#include<stdio.h>
#include<string.h>

/*t -> array of n chars representing text
p -> array of m chars representing pattern

for i=0 to n-m do
	j=0
	while j<m and p[j] = t[i+j] do
		j=j+1
	if j=m return i
return -1
*/

int stringMatching(char* t, char* p){
	int n = strlen(t);
	int m = strlen(p);
	int opcount=0;
	for(int i=0;i<=n-m;i++){
		int j=0;
		opcount++;
		while(j<m && p[j]==t[i+j])
			j=j+1;
		if (j==m){
			printf("Opcount: %d\n", opcount);
			return i;
		}
	}
	printf("Opcount: %d\n", opcount);
	return -1;
}

int main(){
	printf("Enter text: ");
	char t[100];
	scanf("%s", t);
	printf("Enter pattern: ");
	char p[100];
	scanf("%s", p);
	int ind = stringMatching(t,p);
	printf("Found at index: %d\n", ind);
	return 0;
}