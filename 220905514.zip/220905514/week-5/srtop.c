#include<stdio.h>
#include<stdlib.h>

typedef struct node{
	int data;
	struct node* next;
}node;


int main(){
	int vertices;
	printf("Enter no of vertices: ");
	scanf("%d", &vertices);
	node** mat = (node**)malloc(vertices*sizeof(node*));
	//getting the adjacency lists
	for(int i=0;i<vertices;i++){
		mat[i] = (node*)malloc(sizeof(node));
		mat[i]->data = -1;
		node* cur = mat[i];
		printf("Enter adjacency list for vertix %d:-\n", i);
		printf("Enter data or -1 to exit: ");
		int data;
		while(1){
			scanf("%d", &data);
			if(data==-1) break;
			node* temp = (node*)malloc(sizeof(node));
			temp->data=data;
			cur->next = temp;
			cur=temp;
		}
	}
	int flag=1;
	for(int i=0;i<vertices;i++){
		
		while(flag && ){

		}
	}

	return 0;
}