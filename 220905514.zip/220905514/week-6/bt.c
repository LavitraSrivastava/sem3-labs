#include<stdio.h>
#include<stdlib.h>

typedef struct TreeNode{
	int data;
	struct TreeNode* lchild;
	struct TreeNode* rchild;
}TN;

TN* createBT(){
	TN* root = (TN*)malloc(sizeof(TN));
	printf("Enter value or -1 to exit: ");
	int data;
	scanf("%d", &data);
	
	if(data==-1) return NULL;
	else{
		root->data=data;
		printf("Enter lchild of %d\n", data);
		root->lchild=createBT();
		printf("Enter rchild of %d\n", data);
		root->rchild=createBT();
	}
	return root;
}

int opcount=0;
void inorder(TN* root, int* count){
	opcount++;
	if(root){
		inorder(root->lchild, count);
		*count = *count + 1;
		inorder(root->rchild, count);
	}
}

int main(){
	TN* root;
	printf("Enter root node\n");
	root = createBT();
	int count=0;
	inorder(root, &count);
	printf("\nNumber of nodes: %d\n", count);
	printf("Opcount: %d\n", opcount);
	return 0;
}