#include<stdio.h>

int primes[] = {2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,97};


int isPrime(int num){
	int t=2;
	while(t!=num){
		if(num%t==0)
			return 0;
		t++;
	}
	return 1;
}

void factors(int num, int* pf){
	int i=0;
	while(num>1){
		if(num%primes[i]==0){
			*pf = primes[i];
			pf++;
			num = num/primes[i];
		}
		else{
			if(primes[i]==97){
				printf("out of bounds\n");
				return;
			}
			i++;
		}
	}
}

int main(){
	int n1, n2;
	int pf1[50], pf2[50];
	factors(n1, pf1);
	factors(n2, pf2);
	int commons[50];
	int k=0;

	return 0;
}