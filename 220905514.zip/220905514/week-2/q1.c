#include<stdio.h>

int consGCD(int n1, int n2){
	int t = (n1<n2) ? n1:n2;
	int opcount=0;
	while(t>1){
		opcount++;
		if (n1%t == 0){
			if (n2%t == 0){
				printf("Opcount = %d\n", opcount);
				return t;
			}
		}
		t--;
	}
	printf("Opcount = %d\n", opcount);
	return t;
}

int main(){
	int n1, n2;
	printf("Enter numbers: ");
	scanf("%d %d", &n1, &n2);
	int gcd = consGCD(n1,n2);
	printf("n1 + n2 = %d\n", (n1+n2));
	printf("GCD = %d\n", gcd);
	return 0;
}