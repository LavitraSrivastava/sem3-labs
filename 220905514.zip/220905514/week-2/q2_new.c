#include<stdio.h>
int opcount=0;
int isPrime(int num){
	int t=2;
	while(t!=num){
		if(num%t==0)
			return 0;
		t++;
		opcount++;
	}
	return 1;
}

int GCD(int n1, int n2){
	int min = (n1<n2)? n1: n2;
	int max = (n1>n2)? n1: n2;
	int gcd=1;
	int i=2;
	while(i<=min){
		if(isPrime(i) && min%i==0 && max%i==0){
			min/=i;
			max/=i;
			gcd*=i;
		}
		else
			i++;
	}
	printf("Opcount = %d\n", opcount);
	return gcd;
}

int main(){
	int n1, n2;
	printf("Enter numbers: ");
	scanf("%d %d", &n1, &n2);
	printf("n1 + n2 = %d\n", (n1+n2));
	int gcd = GCD(n1,n2);
	printf("GCD = %d\n", gcd);
	return 0;
}