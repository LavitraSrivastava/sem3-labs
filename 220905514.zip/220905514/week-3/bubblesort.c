#include<stdio.h>

void bubbleSort(int* arr, int n){
	int temp;
	int opcount=0;
	for (int i=0;i<n-1;i++){
		for(int j=0;j<n-i-1;j++){
			opcount++;
			if(arr[j]>arr[j+1]){
				temp=arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=temp;
			}
		}
	}
	printf("\nOpcount: %d\n", opcount);
	printf("Sorted list: ");
	for(int i=0;i<n;i++)
		printf("%d ", arr[i]);
	printf("\n");
}


int main(){
	int arr[100];
	int n;
	printf("Enter no of elements: ");
	scanf("%d", &n);
	printf("Elements are: ");
	for (int i=0;i<n;i++){
		arr[i]=n-i;
		printf("%d ", arr[i]);
	}
	bubbleSort(arr, n);
	return 0;
}