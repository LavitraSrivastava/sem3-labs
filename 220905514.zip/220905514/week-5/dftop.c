#include<stdio.h>
#include<stdlib.h>
int stack[20];
int top=-1;
int pop_order[20];
int pop_index=0;

void dfs(int** mat, int vertices, int* visited, int v){
	visited[v]=1; //marked as visited
	stack[++top]=v; // pushed to stack
	for(int i=0;i<vertices;i++)
		if(!visited[i] && mat[v][i] && i!=v)
			dfs(mat, vertices, visited, i);
	int pop=stack[top--]; //popped from stack
	pop_order[pop_index++]=pop+1; // stored in pop_order array
}

int main(){
	int vertices;
	printf("Enter no of vertices: ");
	scanf("%d", &vertices);
	int** mat;
	int* visited;
	mat = (int**)malloc(vertices*sizeof(int*));
	visited = (int*)malloc(vertices*sizeof(int));
	printf("Enter adjacency matrix: \n");
	for(int i=0;i<vertices;i++){
		visited[i]=0;
		mat[i]=(int*)malloc(vertices*sizeof(int));
		for(int j=0;j<vertices;j++)
			scanf("%d", &mat[i][j]);
	}

	
	for(int i=0;i<vertices;i++)
		if(!visited[i])
			dfs(mat, vertices, visited, i);

	printf("Topological sort sequence: ");
	for(int i=pop_index-1;i>=0;i--)
		printf("%d ", pop_order[i]);
	printf("\n");
	return 0;
}